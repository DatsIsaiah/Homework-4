#include <iostream>
using namespace std;

int main() {

    int odd=0;
    int even=0;

    for (int i=0; i<10; i++) {
    
        int input;
        cin >> input;


    //input is divided by 2 and if there is a remainder it marks as odd

    if (input %2 ==0) {
    even++;
    }
    if (input %2 !=0) {
    odd++;
    }
    }

    


    if (even > 1) {
        cout << "There were ";
    cout << even <<" even numbers"<< endl;
    }else {
    cout << "There were no even numbers" << endl;
    }

    if (odd > 1) {
        cout << "There were ";
    cout<< odd <<" odd numbers"<< endl;
    }else {
    cout << "There were no odd numbers" << endl;
    }








    

    return 0;
}